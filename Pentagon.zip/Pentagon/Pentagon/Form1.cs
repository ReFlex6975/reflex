﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pentagon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
                System.Drawing.Drawing2D.GraphicsPath gp = new
                System.Drawing.Drawing2D.GraphicsPath();
                Point[] mp = new Point[5];
                mp[0] = new Point(0, 100);
                mp[1] = new Point(20, 200);
                mp[2] = new Point(300, 200);
                mp[3] = new Point(500, 250);
                mp[4] = new Point(100, 0);
                gp.AddPolygon(mp);
                Region rg = new Region(gp);
                this.Region = rg;
        }
    } 
}
